from deflator.deflator import deflate
from deflator.utils import str_to_float